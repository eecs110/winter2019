Store your database and search results here.
