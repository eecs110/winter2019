---
layout: default
title: Homework 4
nav_exclude: True
---

# Homework 4 Instructions
* Due: Tu, March 5 (11:59PM)
* For detailed instructions, see the [Google Doc](https://docs.google.com/document/d/1OER-Vp96sg7TAN_0Ds04DXdDDiSYvMuW05zmTgRXTSk/edit?usp=sharing).