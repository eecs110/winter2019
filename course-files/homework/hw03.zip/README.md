---
layout: default
title: Homework 3
nav_exclude: True
---

# Homework 3 Instructions
See the [Google Doc](https://docs.google.com/document/d/1ScjwiZfO5bA6R6wdHZ_MU07V-vGkPGx3j-udNibqa_k/edit).