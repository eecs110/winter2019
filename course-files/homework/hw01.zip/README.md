---
layout: default
title: Homework 1
nav_exclude: True
---

# Homework 1 Instructions
Pick *ONE* of the following options for homework 1. Whichever 
option you choose, you'll be sticking with it for the next 6 weeks.

1. [Graphics Track Instructions](https://docs.google.com/document/d/1gg-lejsKe8fihtUsaEYC1I6zjBeWtKJRoCpKdLj8TJY/edit#heading=h.mux0g6mob5hb)
2. [Audio Track Instructions](https://docs.google.com/document/d/1CJQSR8RVhv82PAg2b24oelNUZdmbQkuKuj58N9VeKP4/edit) 

## Due
* Part 1: Tuesday, Jan 22 at 11:59PM
* Part 2: Tuesday, Jan 29 at 11:59PM