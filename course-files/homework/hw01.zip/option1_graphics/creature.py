# replace this function stub with your own code and 
# positional / keyword parameters:
def make_creature(canvas):
    canvas.create_oval(
        [
            (150, 50),  # top left 
            (350, 250)  # bottom right
        ],
        fill='pink'
    )
    canvas.create_oval(
        [
            (215, 110),  # top left 
            (235, 145)  # bottom right
        ],
        fill='black'
    )
    canvas.create_oval(
        [
            (265, 110),  # top left 
            (285, 145)  # bottom right
        ],
        fill='black'
    )