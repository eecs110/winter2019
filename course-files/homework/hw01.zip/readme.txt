
Homework 1 instructions can be found here: https://docs.google.com/document/d/1gg-lejsKe8fihtUsaEYC1I6zjBeWtKJRoCpKdLj8TJY/edit#heading=h.mux0g6mob5hb