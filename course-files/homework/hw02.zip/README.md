---
layout: default
title: Homework 2
nav_exclude: True
---

# Homework 2 Instructions
Pick *ONE* of the following options for homework 2. Whichever 
option you choose, you'll be sticking with it for the next 6 weeks.

1. [Graphics Track Instructions](https://docs.google.com/document/d/1zMMUZokosHmVhTZGvyQbsGk8vR7aOX1BN88zpSDq_Sk/edit?usp=sharing)
2. [Audio Track Instructions](https://docs.google.com/document/d/1pllAi3QzdDmXNrDN-MG1FPlHCkf-exLCyJjI91DgJCA/edit?usp=sharing)

## Due
* Tuesday, Feb 5 at 11:59PM