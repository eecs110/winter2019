Due to size limitations, the Chicago Police Complaints database
(cpd.db) is not included in this folder. To use it, download
it here...

https://drive.google.com/open?id=1QiCaduIMbRaLXfXdQ0ee9yUMT2DXu0eq

...and save it inside your data_sources folder.

Notes about the data can be found here:
http://users.eecs.northwestern.edu/~jennie/courses/eecs396-data-sci/invisible-institute/cpdb-schema/relationships.html