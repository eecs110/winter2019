---
layout: default
nav_order: 0
title: Slides - Lecture 01
nav_exclude: True
---

# SLIDES
* [Slides 00: Intro to the Course](https://docs.google.com/presentation/d/1lFtVbEGrP8PoTZlK-q6SpYLN_B8MDNcN0pBJ_lc7Yd8/edit?usp=sharing)
<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQTV_YXYGm7Lzi5FIyJOaabWly6EEbvhiuHLkX097vuJwxAjoDzP0lv6VFhzpcjtTLIBjFdxYkrU3AQ/embed?start=false&loop=false&delayms=3000" frameborder="0" width="80%" height="400" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>