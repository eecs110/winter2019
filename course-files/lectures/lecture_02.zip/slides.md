---
layout: default
nav_order: 0
title: Slides - Lecture 02
nav_exclude: True
---

# SLIDES
* [Slides 01: Hardware and software](https://docs.google.com/presentation/d/1EGelaCVvS-LME3W5p5KAGBmKWkYaCeWVdEVbUm7G1B0/edit?usp=sharing)
* [Slides 02: Expressions, variables, and statements](https://docs.google.com/presentation/d/1UJKMJ0hVKI1kEm3392xC3R9DvFPtPo3znLjbIhpHEpk/edit?usp=sharing)

## Hardware and software
<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vTRibbLZqCUZpVYHM7cv19Gw-OYMFxzPPo8u-26n8qSHX8RnkpUQCtg7R2RodgDXkyhnxJL-RA3umWy/embed?start=false&loop=false&delayms=3000" frameborder="0" width="80%" height="400" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>

## Expressions, variables, and statements
<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vQfIS4tu6uvp3ISksMSK2vvYlV10E6WH42SKiI3hMWmx0PHRZj_gaMcUHjK4G1Ej2ZXpGYp36K4fTIs/embed?start=false&loop=false&delayms=3000" frameborder="0" width="80%" height="400" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>