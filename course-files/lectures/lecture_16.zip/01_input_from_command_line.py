# get input from command line:
some_val = input('Guess a number between 1 and 100: ')

# output to screen:
print('You chose:', some_val)