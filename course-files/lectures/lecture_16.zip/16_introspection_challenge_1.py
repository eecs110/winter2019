data = {
    'results': [
        {
            'track': {
                'name': 'Crazy In Love',
                'duration': 400
            },
            'artist': {
                'name': 'Beyonce',
                'label': 'Columbia Records',
                'website': 'https://en.wikipedia.org/wiki/Beyonc%C3%A9'
            }
        },
        {
            'track': {
                'name': 'Love On Top',
                'duration': 287
            },
            'artist': {
                'name': 'Beyonce',
                'label': 'Columbia Records',
                'website': 'https://en.wikipedia.org/wiki/Beyonc%C3%A9'
            }
        }
    ],
    'total': 300,
    'page_num': 1
}

'''
Challenge: using the same strategy as in file 14, how do
I print all of the track titles? 
'''