def in_between(num, high, low):
    return num > high and num < low

print(in_between(90, 20, 70))
print(in_between(30, 20, 70))