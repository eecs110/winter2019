# example 1:
result = 2 * '22'
print('The result is:', result)

# example 2:
result = '2' * 22
print('The result is:', result)

# example 3:
result = 2 * 22
print('The result is:', result)

# example 4: 
result = max(1, 3, 4 + 8, 9, 3 * 33)

# example 5:
from operator import add, sub, mul
result = sub(100, mul(7, add(8, 4)))
