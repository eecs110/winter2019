#example: print all keys and values one by one:
eng2sp = {
    'one': 'uno', 
    'two': 'dos', 
    'three': 'tres'
}
for key in eng2sp:
    print(key, eng2sp[key], sep=': ')