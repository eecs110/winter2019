---
layout: default
title: Tutorial 6
nav_exclude: True
---

# Tutorial 6 Instructions
See the [Google Doc](https://docs.google.com/document/d/1DmEdNejLU2UBahXTq625lSdR23tN7rQhLdm2qUOMZ1E/edit?usp=sharing).