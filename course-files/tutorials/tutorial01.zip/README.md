---
layout: default
nav_order: 1
title: Instructions
nav_exclude: True
---
# INSTRUCTIONS
Tutorial 1 instructions can be found <a href="https://docs.google.com/document/d/1D2Y6u2hZm2zdyLB9IRjrS-IKhDR1v65ZfgxYIVYc0Hk/edit?usp=sharing" target="_blank">here <i class="fas fa-external-link-alt"></i></a>.