---
layout: default
title: Tutorial 8
nav_exclude: True
---

# Tutorial 8 Instructions
See the [Google Doc](https://docs.google.com/document/d/1PBEsbcn6MzdLrTnk_KJ_uFCkNH3PuOdUKqgI_6MzhWs/edit?usp=sharing).