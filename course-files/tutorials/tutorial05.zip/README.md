---
layout: default
title: Tutorial 5
nav_exclude: True
---

# Tutorial 5 Instructions
See the [Google Doc](https://docs.google.com/document/d/1wavstSsEJODH7GcZN9HhSmTam3YoGqepQGmIBodFgTI/edit?usp=sharing).