---
layout: default
title: Tutorial 7
nav_exclude: True
---

# Tutorial 7 Instructions
See the [Google Doc](https://docs.google.com/document/d/1Pbcu_Fv8TmZ-r_mLgT-wsZ0z8GpkwfVIVK6OaBf-KE8/edit#heading=h.7hxfqpi0rl0f).