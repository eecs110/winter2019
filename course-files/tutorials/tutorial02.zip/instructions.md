---
layout: default
title: Tutorial 02
nav_order: 1
nav_exclude: True
permalink: /course-files/tutorials/tutorial02/instructions
---

# Tutorial 02

Please see the [google doc]((https://docs.google.com/document/d/1MXhfSxaU61Si__bWSefMOzmFRcLPp2kCnKqvmKSAOLQ/edit?usp=sharing).