---
layout: default
title: Project 1
nav_exclude: True
---

# Project 1 Instructions
Pick *ONE* of the following options for project 1, which is worth 60 points.

1. [Graphics Track Instructions](https://docs.google.com/document/d/12Dh6zlNtIGixbX2ja_rfO42z0tAlTV0ARkWO0eaGKgk/edit?usp=sharing)
2. [Audio Track Instructions](https://docs.google.com/document/d/1JGA8eKsTHve5URc5dC3EVx6IceHOuWFrtu-4fYoTlNQ/edit?usp=sharing) 

## Due
* Get as much as you can done for homework 3<br>**Due Tu, Feb 19 at 11:59PM**
* Entire project<br>**Due Tu, Feb 26 at 11:59PM**. Late penaly of 20% for projects that are 48 hours late. No projects will be accepted after that.

## Project Showcase
What a fantastic set of submissions. Take a look at your [collective excellence](https://photos.app.goo.gl/cFWF13ARLgm74mVP6). Well done, everyone.
