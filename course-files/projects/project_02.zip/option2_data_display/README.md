---
layout: default
title: Homework 5
nav_exclude: True
---

# P2: DATA DISPLAY PROJECT
For the Data Display project, please follow [the instructions in the Google Doc](https://docs.google.com/document/d/1KccLv85K3HXYB4NK2w3NEa0xpE3_xgiEvoQ6sgp_3NY/edit?usp=sharing).


## Resources & Tips
We have also compiled a list of code samples and resources that may be helpful to you as you begin your project, located in the samples folder.