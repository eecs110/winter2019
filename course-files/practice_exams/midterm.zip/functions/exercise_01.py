## FIXED VERSION
def print_message(name):
    print('Hello, ' + name + '!')

# ## BROKEN VERSION
# def print_message(name):
#     print('Hello, name!')

print_message('Jelani')
print_message('Merissa')
