my_list = ['blue', 'purple', 'red', 'green', 'black']
a = my_list.pop(0)
b = my_list.pop(2)
print(a)
print(b)
print(my_list)
